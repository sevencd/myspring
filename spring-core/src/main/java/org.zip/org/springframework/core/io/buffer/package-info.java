/**
 * Generic abstraction for working with byte buffer implementations.
 */
package org.springframework.core.io.buffer;

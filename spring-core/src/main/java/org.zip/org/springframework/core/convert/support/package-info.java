/**
 * Default implementation of the type conversion system.
 */
package org.springframework.core.convert.support;

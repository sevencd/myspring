/**
 * Support classes for reading annotation and class-level metadata.
 */
package org.springframework.core.type.classreading;

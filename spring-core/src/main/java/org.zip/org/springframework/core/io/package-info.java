/**
 * Generic abstraction for (file-based) resources, used throughout the framework.
 */
package org.springframework.core.io;

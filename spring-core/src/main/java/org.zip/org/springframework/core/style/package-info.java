/**
 * Support for styling values as Strings, with ToStringCreator as central class.
 */
package org.springframework.core.style;

/**
 * {@link org.springframework.core.codec.Encoder} and
 * {@link org.springframework.core.codec.Decoder} abstractions to convert
 * between a reactive stream of bytes and Java objects.
 */
package org.springframework.core.codec;

/**
 * Useful generic {@code java.util.concurrent.Future} extension.
 */
package org.springframework.util.concurrent;

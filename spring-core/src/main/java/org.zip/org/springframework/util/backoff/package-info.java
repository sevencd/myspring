/**
 * A generic back-off abstraction.
 */
package org.springframework.util.backoff;
